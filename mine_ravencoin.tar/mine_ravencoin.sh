#!/bin/sh
./miner --algo kawpow --server rvn.2miners.com:6060 --user RWLSgYe3kuYzP33qwe5StumRvqmcDjg4vn
